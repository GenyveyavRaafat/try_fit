import '/backend/firebase_storage/storage.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/upload_data.dart';
import 'dart:ui';
import 'media_access_dropdown_widget.dart' show MediaAccessDropdownWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class MediaAccessDropdownModel
    extends FlutterFlowModel<MediaAccessDropdownWidget> {
  ///  State fields for stateful widgets in this component.

  bool isDataUploading_uploadData6x8 = false;
  FFUploadedFile uploadedLocalFile_uploadData6x8 =
      FFUploadedFile(bytes: Uint8List.fromList([]));
  String uploadedFileUrl_uploadData6x8 = '';

  bool isDataUploading_uploadDataXp3 = false;
  FFUploadedFile uploadedLocalFile_uploadDataXp3 =
      FFUploadedFile(bytes: Uint8List.fromList([]));
  String uploadedFileUrl_uploadDataXp3 = '';

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
