// Export pages
export '/pages/login/login_widget.dart' show LoginWidget;
export '/pages/register/register_widget.dart' show RegisterWidget;
export '/pages/startpage/startpage_widget.dart' show StartpageWidget;
export '/pages/home/home_widget.dart' show HomeWidget;
export '/pages/profile/profile_widget.dart' show ProfileWidget;
export '/pages/editprofile/editprofile_widget.dart' show EditprofileWidget;
export '/pages/aboutus/aboutus_widget.dart' show AboutusWidget;
export '/pages/reset/reset_widget.dart' show ResetWidget;
export '/pages/loading_page/loading_page_widget.dart' show LoadingPageWidget;
export '/pages/downloads/downloads_widget.dart' show DownloadsWidget;
export '/pages/upper/upper_widget.dart' show UpperWidget;
export '/pages/lower/lower_widget.dart' show LowerWidget;
export '/pages/full/full_widget.dart' show FullWidget;
export '/pages/wishlist2/wishlist2_widget.dart' show Wishlist2Widget;
export '/pages/try_on/try_on_widget.dart' show TryOnWidget;
export '/pages/product/product_widget.dart' show ProductWidget;
export '/pages/result/result_widget.dart' show ResultWidget;
export '/pages/showdownloads/showdownloads_widget.dart'
    show ShowdownloadsWidget;
export '/pages/login_copy/login_copy_widget.dart' show LoginCopyWidget;
export '/pages/search/search_widget.dart' show SearchWidget;
export '/pages/forgetpassword/forgetpassword_widget.dart'
    show ForgetpasswordWidget;
export '/pages/additem/additem_widget.dart' show AdditemWidget;
export '/pages/deleteitem/deleteitem_widget.dart' show DeleteitemWidget;
