import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class TryOnRecord extends FirestoreRecord {
  TryOnRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "user_id" field.
  String? _userId;
  String get userId => _userId ?? '';
  bool hasUserId() => _userId != null;

  // "model_img" field.
  String? _modelImg;
  String get modelImg => _modelImg ?? '';
  bool hasModelImg() => _modelImg != null;

  // "cloth_img" field.
  String? _clothImg;
  String get clothImg => _clothImg ?? '';
  bool hasClothImg() => _clothImg != null;

  // "output_img" field.
  String? _outputImg;
  String get outputImg => _outputImg ?? '';
  bool hasOutputImg() => _outputImg != null;

  // "status" field.
  String? _status;
  String get status => _status ?? '';
  bool hasStatus() => _status != null;

  // "category_name" field.
  String? _categoryName;
  String get categoryName => _categoryName ?? '';
  bool hasCategoryName() => _categoryName != null;

  // "datetime" field.
  String? _datetime;
  String get datetime => _datetime ?? '';
  bool hasDatetime() => _datetime != null;

  void _initializeFields() {
    _userId = snapshotData['user_id'] as String?;
    _modelImg = snapshotData['model_img'] as String?;
    _clothImg = snapshotData['cloth_img'] as String?;
    _outputImg = snapshotData['output_img'] as String?;
    _status = snapshotData['status'] as String?;
    _categoryName = snapshotData['category_name'] as String?;
    _datetime = snapshotData['datetime'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('TryOn');

  static Stream<TryOnRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => TryOnRecord.fromSnapshot(s));

  static Future<TryOnRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => TryOnRecord.fromSnapshot(s));

  static TryOnRecord fromSnapshot(DocumentSnapshot snapshot) => TryOnRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static TryOnRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      TryOnRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'TryOnRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is TryOnRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createTryOnRecordData({
  String? userId,
  String? modelImg,
  String? clothImg,
  String? outputImg,
  String? status,
  String? categoryName,
  String? datetime,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'user_id': userId,
      'model_img': modelImg,
      'cloth_img': clothImg,
      'output_img': outputImg,
      'status': status,
      'category_name': categoryName,
      'datetime': datetime,
    }.withoutNulls,
  );

  return firestoreData;
}

class TryOnRecordDocumentEquality implements Equality<TryOnRecord> {
  const TryOnRecordDocumentEquality();

  @override
  bool equals(TryOnRecord? e1, TryOnRecord? e2) {
    return e1?.userId == e2?.userId &&
        e1?.modelImg == e2?.modelImg &&
        e1?.clothImg == e2?.clothImg &&
        e1?.outputImg == e2?.outputImg &&
        e1?.status == e2?.status &&
        e1?.categoryName == e2?.categoryName &&
        e1?.datetime == e2?.datetime;
  }

  @override
  int hash(TryOnRecord? e) => const ListEquality().hash([
        e?.userId,
        e?.modelImg,
        e?.clothImg,
        e?.outputImg,
        e?.status,
        e?.categoryName,
        e?.datetime
      ]);

  @override
  bool isValidKey(Object? o) => o is TryOnRecord;
}
