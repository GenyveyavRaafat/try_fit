import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class DownloadsRecord extends FirestoreRecord {
  DownloadsRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "download_img" field.
  String? _downloadImg;
  String get downloadImg => _downloadImg ?? '';
  bool hasDownloadImg() => _downloadImg != null;

  // "user_id" field.
  String? _userId;
  String get userId => _userId ?? '';
  bool hasUserId() => _userId != null;

  // "category_name" field.
  String? _categoryName;
  String get categoryName => _categoryName ?? '';
  bool hasCategoryName() => _categoryName != null;

  // "date" field.
  DateTime? _date;
  DateTime? get date => _date;
  bool hasDate() => _date != null;

  void _initializeFields() {
    _downloadImg = snapshotData['download_img'] as String?;
    _userId = snapshotData['user_id'] as String?;
    _categoryName = snapshotData['category_name'] as String?;
    _date = snapshotData['date'] as DateTime?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('downloads');

  static Stream<DownloadsRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => DownloadsRecord.fromSnapshot(s));

  static Future<DownloadsRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => DownloadsRecord.fromSnapshot(s));

  static DownloadsRecord fromSnapshot(DocumentSnapshot snapshot) =>
      DownloadsRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static DownloadsRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      DownloadsRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'DownloadsRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is DownloadsRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createDownloadsRecordData({
  String? downloadImg,
  String? userId,
  String? categoryName,
  DateTime? date,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'download_img': downloadImg,
      'user_id': userId,
      'category_name': categoryName,
      'date': date,
    }.withoutNulls,
  );

  return firestoreData;
}

class DownloadsRecordDocumentEquality implements Equality<DownloadsRecord> {
  const DownloadsRecordDocumentEquality();

  @override
  bool equals(DownloadsRecord? e1, DownloadsRecord? e2) {
    return e1?.downloadImg == e2?.downloadImg &&
        e1?.userId == e2?.userId &&
        e1?.categoryName == e2?.categoryName &&
        e1?.date == e2?.date;
  }

  @override
  int hash(DownloadsRecord? e) => const ListEquality()
      .hash([e?.downloadImg, e?.userId, e?.categoryName, e?.date]);

  @override
  bool isValidKey(Object? o) => o is DownloadsRecord;
}
