import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class CategoriesRecord extends FirestoreRecord {
  CategoriesRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "category_name" field.
  String? _categoryName;
  String get categoryName => _categoryName ?? '';
  bool hasCategoryName() => _categoryName != null;

  // "id" field.
  String? _id;
  String get id => _id ?? '';
  bool hasId() => _id != null;

  // "image_url" field.
  String? _imageUrl;
  String get imageUrl => _imageUrl ?? '';
  bool hasImageUrl() => _imageUrl != null;

  // "clothing_type" field.
  String? _clothingType;
  String get clothingType => _clothingType ?? '';
  bool hasClothingType() => _clothingType != null;

  // "colors" field.
  String? _colors;
  String get colors => _colors ?? '';
  bool hasColors() => _colors != null;

  // "discription" field.
  String? _discription;
  String get discription => _discription ?? '';
  bool hasDiscription() => _discription != null;

  void _initializeFields() {
    _categoryName = snapshotData['category_name'] as String?;
    _id = snapshotData['id'] as String?;
    _imageUrl = snapshotData['image_url'] as String?;
    _clothingType = snapshotData['clothing_type'] as String?;
    _colors = snapshotData['colors'] as String?;
    _discription = snapshotData['discription'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('categories');

  static Stream<CategoriesRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => CategoriesRecord.fromSnapshot(s));

  static Future<CategoriesRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => CategoriesRecord.fromSnapshot(s));

  static CategoriesRecord fromSnapshot(DocumentSnapshot snapshot) =>
      CategoriesRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static CategoriesRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      CategoriesRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'CategoriesRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is CategoriesRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createCategoriesRecordData({
  String? categoryName,
  String? id,
  String? imageUrl,
  String? clothingType,
  String? colors,
  String? discription,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'category_name': categoryName,
      'id': id,
      'image_url': imageUrl,
      'clothing_type': clothingType,
      'colors': colors,
      'discription': discription,
    }.withoutNulls,
  );

  return firestoreData;
}

class CategoriesRecordDocumentEquality implements Equality<CategoriesRecord> {
  const CategoriesRecordDocumentEquality();

  @override
  bool equals(CategoriesRecord? e1, CategoriesRecord? e2) {
    return e1?.categoryName == e2?.categoryName &&
        e1?.id == e2?.id &&
        e1?.imageUrl == e2?.imageUrl &&
        e1?.clothingType == e2?.clothingType &&
        e1?.colors == e2?.colors &&
        e1?.discription == e2?.discription;
  }

  @override
  int hash(CategoriesRecord? e) => const ListEquality().hash([
        e?.categoryName,
        e?.id,
        e?.imageUrl,
        e?.clothingType,
        e?.colors,
        e?.discription
      ]);

  @override
  bool isValidKey(Object? o) => o is CategoriesRecord;
}
