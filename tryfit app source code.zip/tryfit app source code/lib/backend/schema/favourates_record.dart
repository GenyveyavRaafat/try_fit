import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class FavouratesRecord extends FirestoreRecord {
  FavouratesRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "img_url" field.
  String? _imgUrl;
  String get imgUrl => _imgUrl ?? '';
  bool hasImgUrl() => _imgUrl != null;

  // "u_id" field.
  String? _uId;
  String get uId => _uId ?? '';
  bool hasUId() => _uId != null;

  // "img_id" field.
  DocumentReference? _imgId;
  DocumentReference? get imgId => _imgId;
  bool hasImgId() => _imgId != null;

  void _initializeFields() {
    _imgUrl = snapshotData['img_url'] as String?;
    _uId = snapshotData['u_id'] as String?;
    _imgId = snapshotData['img_id'] as DocumentReference?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('favourates');

  static Stream<FavouratesRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => FavouratesRecord.fromSnapshot(s));

  static Future<FavouratesRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => FavouratesRecord.fromSnapshot(s));

  static FavouratesRecord fromSnapshot(DocumentSnapshot snapshot) =>
      FavouratesRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static FavouratesRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      FavouratesRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'FavouratesRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is FavouratesRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createFavouratesRecordData({
  String? imgUrl,
  String? uId,
  DocumentReference? imgId,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'img_url': imgUrl,
      'u_id': uId,
      'img_id': imgId,
    }.withoutNulls,
  );

  return firestoreData;
}

class FavouratesRecordDocumentEquality implements Equality<FavouratesRecord> {
  const FavouratesRecordDocumentEquality();

  @override
  bool equals(FavouratesRecord? e1, FavouratesRecord? e2) {
    return e1?.imgUrl == e2?.imgUrl &&
        e1?.uId == e2?.uId &&
        e1?.imgId == e2?.imgId;
  }

  @override
  int hash(FavouratesRecord? e) =>
      const ListEquality().hash([e?.imgUrl, e?.uId, e?.imgId]);

  @override
  bool isValidKey(Object? o) => o is FavouratesRecord;
}
