import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyDh36px-nQyavCf_z9DVCTozPKPNOCoFPU",
            authDomain: "vton-yx1pe4.firebaseapp.com",
            projectId: "vton-yx1pe4",
            storageBucket: "vton-yx1pe4.firebasestorage.app",
            messagingSenderId: "616462855103",
            appId: "1:616462855103:web:c7aa9330bf781835a70f0a"));
  } else {
    await Firebase.initializeApp();
  }
}
