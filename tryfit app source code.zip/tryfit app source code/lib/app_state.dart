import 'package:flutter/material.dart';
import '/backend/backend.dart';
import '/backend/api_requests/api_manager.dart';
import 'backend/supabase/supabase.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'flutter_flow/flutter_flow_util.dart';

class FFAppState extends ChangeNotifier {
  static FFAppState _instance = FFAppState._internal();

  factory FFAppState() {
    return _instance;
  }

  FFAppState._internal();

  static void reset() {
    _instance = FFAppState._internal();
  }

  Future initializePersistedState() async {}

  void update(VoidCallback callback) {
    callback();
    notifyListeners();
  }

  bool _isVafouriteEmpty = true;
  bool get isVafouriteEmpty => _isVafouriteEmpty;
  set isVafouriteEmpty(bool value) {
    _isVafouriteEmpty = value;
  }

  List<DocumentReference> _ListVafourites = [];
  List<DocumentReference> get ListVafourites => _ListVafourites;
  set ListVafourites(List<DocumentReference> value) {
    _ListVafourites = value;
  }

  void addToListVafourites(DocumentReference value) {
    ListVafourites.add(value);
  }

  void removeFromListVafourites(DocumentReference value) {
    ListVafourites.remove(value);
  }

  void removeAtIndexFromListVafourites(int index) {
    ListVafourites.removeAt(index);
  }

  void updateListVafouritesAtIndex(
    int index,
    DocumentReference Function(DocumentReference) updateFn,
  ) {
    ListVafourites[index] = updateFn(_ListVafourites[index]);
  }

  void insertAtIndexInListVafourites(int index, DocumentReference value) {
    ListVafourites.insert(index, value);
  }

  String _profileImagePath = '';
  String get profileImagePath => _profileImagePath;
  set profileImagePath(String value) {
    _profileImagePath = value;
  }

  String _ModelImagePath = '';
  String get ModelImagePath => _ModelImagePath;
  set ModelImagePath(String value) {
    _ModelImagePath = value;
  }

  String _clothImage = '';
  String get clothImage => _clothImage;
  set clothImage(String value) {
    _clothImage = value;
  }

  String _searchText = '\" \"';
  String get searchText => _searchText;
  set searchText(String value) {
    _searchText = value;
  }

  String _searchText2 = '\" \"';
  String get searchText2 => _searchText2;
  set searchText2(String value) {
    _searchText2 = value;
  }

  bool _isFavourite = false;
  bool get isFavourite => _isFavourite;
  set isFavourite(bool value) {
    _isFavourite = value;
  }

  String _NewItemImage = '';
  String get NewItemImage => _NewItemImage;
  set NewItemImage(String value) {
    _NewItemImage = value;
  }
}
