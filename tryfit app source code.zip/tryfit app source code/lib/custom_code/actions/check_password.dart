// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/backend/supabase/supabase.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'package:firebase_auth/firebase_auth.dart';

Future<bool> checkPassword(String email, String currentPassword) async {
  try {
    if (email.isEmpty || currentPassword.isEmpty) {
      print("Email or password is empty.");
      return false;
    }

    FirebaseAuth _auth = FirebaseAuth.instance;
    await _auth.signInWithEmailAndPassword(
      email: email,
      password: currentPassword,
    );
    return true;
  } on FirebaseAuthException catch (e) {
    if (e.code == 'wrong-password' || e.code == 'user-not-found') {
      print("Incorrect email or password.");
    } else {
      print("FirebaseAuthException: ${e.code} - ${e.message}");
    }
    return false;
  } catch (e) {
    print("Unexpected error: $e");
    return false;
  }
}
