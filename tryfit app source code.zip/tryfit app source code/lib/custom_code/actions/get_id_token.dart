// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/backend/supabase/supabase.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'package:firebase_auth/firebase_auth.dart';

Future<String?> getIdToken() async {
  try {
    final auth = FirebaseAuth.instance;
    final user = auth.currentUser;

    if (user == null) {
      print('❌ No user is logged in.');
      return null;
    }

    final idToken = await user.getIdToken(true); // Force refresh
    print('✅ ID Token: $idToken');
    return idToken;
  } catch (e) {
    print('❌ Error getting ID token: $e');
    return null;
  }
}
// Set your action name, define your arguments and return parameter,
// and then add the boilerplate code using the green button on the right!
