package com.mycompany.vton2020

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
